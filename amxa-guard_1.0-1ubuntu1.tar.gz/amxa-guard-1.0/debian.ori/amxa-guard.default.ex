# Defaults for amxa-guard initscript
# sourced by /etc/init.d/amxa-guard
# installed at /etc/default/amxa-guard by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
