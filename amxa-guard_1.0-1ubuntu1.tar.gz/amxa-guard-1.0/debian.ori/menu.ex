?package(amxa-guard):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="amxa-guard" command="/usr/bin/amxa-guard"
